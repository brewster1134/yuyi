class FooRollModel < Yuyi::Roll
end
