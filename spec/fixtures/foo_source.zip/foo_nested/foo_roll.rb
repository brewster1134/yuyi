class FooRoll < Yuyi::Roll
end
