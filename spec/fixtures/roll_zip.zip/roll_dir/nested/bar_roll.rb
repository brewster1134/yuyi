class BarRoll < Yuyi::Roll
end
